// PopupContainer.jsx
import React, { useState } from 'react';
import Login from './Login';
import Signup from './Signup';

function PopupContainer() {
  const [showLogin, setShowLogin] = useState(true);
  const [showSignup, setShowSignup] = useState(false);

  const toggleLogin = () => {
    setShowLogin(!showLogin);
  };

  const toggleSignup = () => {
    setShowSignup(!showSignup);
  };

  return (
    <div>
      {showLogin && <Login onSignupClick={toggleSignup} />}
      {showSignup && <Signup onClose={toggleLogin} />}
    </div>
  );
}

export default PopupContainer;

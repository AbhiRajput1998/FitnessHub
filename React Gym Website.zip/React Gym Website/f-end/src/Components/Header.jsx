import React, { useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import Login from './Login'; 

function Header() {
  const [showLogin, setShowLogin] = useState(false);

  const handleLoginClose = () => setShowLogin(false);
  const handleLoginShow = () => setShowLogin(true);

  return (
    <div id='main'>
      <div className='pr-heading'>
       <h2> STEP UP YOUR</h2>
        <h1><span>FITNESS</span>WITH US</h1>
        <p className='details'>
    Build Your Body And Fitness With Professional Touch
         </p>
      <div className='header-btns'>
        <Button variant='outline-danger' style={{fontSize:'25px'}} onClick={handleLoginShow}>
          JOIN US
        </Button>
      </div>

      {/* Login Modal */}
      <Modal show={showLogin} onHide={handleLoginClose}>
        <Modal.Header closeButton>
          <Modal.Title>Login</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {/* Render your login component here */}
          <Login />
        </Modal.Body>
        <Modal.Footer>
          <Button variant='outline-danger' onClick={handleLoginClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
    </div>
  );
}

export default Header;
